# EVE Living Intelligence

EVE is a Living Intelligence for Humanity — a mobile-first AI web app built on the Human Engine, created for the Human Return.

## Run & Operate

- `pnpm --filter @workspace/eve run dev` — run the EVE front-end (Vite)
- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Front-end: React 19 + Vite 6, Tailwind CSS v4, Framer Motion, shadcn/ui
- Routing: wouter
- Fonts: Cormorant Garamond (serif headings) + Inter (body)
- API: Express 5
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/eve/` — main React/Vite front-end (landing page + chat UI)
- `artifacts/api-server/` — Express API server
- `artifacts/eve/src/pages/home.tsx` — the full single-page layout
- `artifacts/eve/src/index.css` — theme palette, font imports

## Architecture decisions

- Single-page layout — hero, mission, chat, engines, footer all in one scroll
- Mobile-first (iPhone-first) — all spacing and type scales are clamp-based
- Chat is local/mock only in the prototype — no backend AI calls yet
- Framer Motion `whileInView` for scroll-triggered section reveals
- Dark warm palette: background `24 10% 6%`, primary `40 50% 65%` (warm gold)

## Product

EVE is a living AI presence. The landing page introduces her identity, lets users type a message to her (mock response prototype), and presents her 10 core engines.

## User preferences

- Brand: dark, warm, elegant, human, futuristic — not cold or corporate
- No login, no payments, no API keys in this prototype phase
- Mobile-first always; iPhone Safari is the primary target

## Gotchas

- Google Font `@import url(...)` must be the very first line of `index.css` — before `@import "tailwindcss"`
- All CSS custom property placeholders must be replaced (no red values remain)
- `whileInView` animations start at `opacity: 0` — they appear invisible in full-page static screenshots but work correctly on live scroll

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
- GitHub repo: hernandezadel77-prog/eve-living-intelligence
